import cv2
import numpy as np

image1 = cv2.imread("i1.jpg")
image2 = cv2.imread("i2.jpg")

difference = cv2.subtract(image1, image2)
result = not np.any(difference) #if there is no difference than it will return false

if result is True:
    print("The image are same.")
else:
    cv2.imwrite("result.jpg",difference)
    print("The images are different.")

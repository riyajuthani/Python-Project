import numpy as np
import cv2

#main Image
im1 = cv2.imread('i1.jpg')
height, width, depth = im1.shape
print (height, width, depth)
thresh1 = 132
imgray1 = cv2.cvtColor(im1,cv2.COLOR_BGR2GRAY)
blur1 = cv2.GaussianBlur(imgray1,(5,5),0)
edges1 = cv2.Canny(blur1,thresh1,thresh1*2)
contours, hierarchy = cv2.findContours(edges1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
cnt1 = contours[0]
cv2.drawContours(im1,contours,-1,(0,255,0),-1)

#centroid_x = M10/M00 and centroid_y = M01/M00
M1 = cv2.moments(cnt1)
x1 = int(M1['m10']/M1['m00'])
y1 = int(M1['m01']/M1['m00'])
print ("Coordinates of Main Image: ",x1,y1)
#print (int(width/2),int(height/2))
#print (int(width/2-x),int(height/2-y))


cv2.circle(im1,(x1,y1),1,(0,0,255),2)
cv2.putText(im1,"center", (x1,y1), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255))
cv2.circle(im1,(int(width/2),int(height/2)),1,(255,0,0),2)
cv2.putText(im1,"center of image", (int(width/2),int(height/2)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0))
cv2.imshow('contour',im1)
#cv2.waitKey(0)


#2nd Image
im = cv2.imread('i5.jpg')
height, width, depth = im.shape
print (height, width, depth)
thresh = 132
imgray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
blur = cv2.GaussianBlur(imgray,(5,5),0)
edges = cv2.Canny(blur,thresh,thresh*2)
contours, hierarchy = cv2.findContours(edges,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
cnt = contours[0]
cv2.drawContours(im,contours,-1,(0,255,0),-1)

#centroid_x = M10/M00 and centroid_y = M01/M00
M = cv2.moments(cnt)
x2 = int(M['m10']/M['m00'])
y2 = int(M['m01']/M['m00'])
print ("Coordinates of 2nd Image: ",x2,y2)
#print (int(width/2),int(height/2))
#print (int(width/2-x),int(height/2-y))


cv2.circle(im,(x2,y2),1,(0,0,255),2)
cv2.putText(im,"center", (x2,y2), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255))
cv2.circle(im,(int(width/2),int(height/2)),1,(255,0,0),2)
cv2.putText(im,"center of image", (int(width/2),int(height/2)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0))
cv2.imshow('contours',im)
#cv2.waitKey(0)

#Comparing 2 images
if y1 == y2:
    if x1 > x2:
        print("The Circle moved towards Left from its original position.")
    elif x1 < x2:
        print("The Circle moved towards Right from its original position.")
    else:
        print("The Circle is on its original position.")
elif x1 == x2:
    if y1 > y2:
        print("The Circle moved towards up from its original position.")
    elif y1 < y2:
        print("The Circle moved towards down from its original position.")
    else:
        print("The Circle is on its original position.")
